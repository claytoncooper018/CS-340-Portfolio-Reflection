# AnimalShelter.py
# Author: Student
# CS 340 - Project Two
# CRUD operations for the Austin Animal Center (AAC) MongoDB database

from pymongo import MongoClient
from pymongo.errors import PyMongoError


class AnimalShelter:
    """
    A class to provide CRUD (Create, Read, Update, Delete) operations
    for the Austin Animal Center (AAC) MongoDB database.
    """

    def __init__(self, username, password):
        """
        Initialize the MongoClient connection to the AAC database.

        Parameters:
            username (str): MongoDB username with access to the aac database.
            password (str): Corresponding password for the MongoDB user.
        """
        try:
            self.client = MongoClient(
                "localhost",
                27017,
                username=username,
                password=password,
                authSource="admin"
            )
            self.database = self.client['aac']
            self.collection = self.database['animals']
            # Verify connection with a ping command
            self.database.command("ping")
            print("Connection successful")
        except PyMongoError as e:
            print(f"Connection error: {e}")

    # -------------------------
    # CREATE
    # -------------------------
    def create(self, data):
        """
        Insert a single document into the animals collection.

        Parameters:
            data (dict): The document to insert.

        Returns:
            bool: True if insertion was successful, False otherwise.
        """
        if data and isinstance(data, dict):
            try:
                self.collection.insert_one(data)
                return True
            except PyMongoError as e:
                print(f"Insertion error: {e}")
        else:
            print("Create error: 'data' must be a non-empty dictionary.")
        return False

    # -------------------------
    # READ
    # -------------------------
    def read(self, query):
        """
        Query for documents in the animals collection.

        Parameters:
            query (dict): A MongoDB query document. Pass {} to retrieve all records.

        Returns:
            list: A list of matching documents, or an empty list on error.
        """
        try:
            results = self.collection.find(query, {'_id': False})
            return list(results)
        except PyMongoError as e:
            print(f"Read error: {e}")
            return []

    # -------------------------
    # UPDATE
    # -------------------------
    def update(self, query, update_values):
        """
        Update all documents matching the query with the given values.

        Parameters:
            query (dict): A MongoDB query to select documents to update.
            update_values (dict): Key-value pairs to set on matched documents.

        Returns:
            int: Number of documents modified, or 0 on error.
        """
        try:
            result = self.collection.update_many(query, {"$set": update_values})
            return result.modified_count
        except PyMongoError as e:
            print(f"Update error: {e}")
            return 0

    # -------------------------
    # DELETE
    # -------------------------
    def delete(self, query):
        """
        Delete all documents matching the query from the animals collection.

        Parameters:
            query (dict): A MongoDB query to select documents for deletion.

        Returns:
            int: Number of documents deleted, or 0 on error.
        """
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except PyMongoError as e:
            print(f"Delete error: {e}")
            return 0
